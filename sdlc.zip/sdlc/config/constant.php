<?php
// dinh nghia cac hang so
const APP_PATH_VIEW = 'view/';
const APP_PATH_CONTROLLER = 'controller/';
const APP_PATH_MODEL = 'model/';
const APP_ROOT_PATH = 'index.php';

const LIMIT_ITEM_PAGE = 2;